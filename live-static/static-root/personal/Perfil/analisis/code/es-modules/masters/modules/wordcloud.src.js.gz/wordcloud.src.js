/**
 * @license Highcharts JS v9.1.1 (2021-06-03)
 * @module highcharts/modules/wordcloud
 * @requires highcharts
 *
 * (c) 2016-2021 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Wordcloud/WordcloudSeries.js';
